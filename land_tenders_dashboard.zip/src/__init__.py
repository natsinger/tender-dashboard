"""Land Tenders Dashboard - Data Module"""
from .data_client import LandTendersClient, generate_sample_data, normalize_hebrew_columns
